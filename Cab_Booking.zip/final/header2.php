<html>

<head>
		<title>Customer Panel</title>
		<link href="css/style.css" rel="stylesheet" type="text/css"  media="all" />
		<link rel="stylesheet" href="css/responsiveslides.css">
		<script src="js/responsiveslides.min.js"></script>
		  <script>
		    // You can also use "$(window).load(function() {"
			    $(function () {
			
			      // Slideshow 1
			      $("#slider1").responsiveSlides({
			        maxwidth: 1600,
			        speed: 600
			      });
			});
		  </script>
	</head>
<body>
	<div class="header">
			<!---start-wrap---->
			<div class="wrap">
				<!---start-top-header---->
				<div class="top-header">
					<div class="top-header-left">
						
					
					</div>
					<div class="top-header-right">
						<div class="top-header-contact-info">
							<p>GET FREE CONSULTATION:</p>
							<span>8593890772</span>
						</div>
						<div class="top-header-contact-account">
							<div class="sub-about-grid-social">
								<ul>
									<li><a href="https://www.facebook.com"><img src="images/facebook.png" title="facebook"></a></li>
									<li><a href="https://www.twitter.com"><img src="images/twitter.png" title="Twiiter"></a></li>
									<li><a href="https://www.google.com"><img src="images/gpluse.png" title="Google+"></a></li>
								</ul>
							</div>
						</div>
						<div class="clear"> </div>
					</div>
					<div class="clear"> </div>
				</div>
                
				<!---End-top-header---->
				<!----start-main-header----->
				<div class="main-header">
					<div class="logo">
						<a href="#"><img src="images/logo1.png" title="logo" /></a>
					</div>
					<div class="top-nav">
						<ul>
							<li class="active"><a href="home.php">Home</a></li>
							<li><a href="advbooking.html">Booking</a></li>
							<li><a href="feedback.html">Contact Us</a></li>
							<li><a href="index.html">Signout</a></li>
							<div class="clear"> </div>
						</ul>
					</div>
					<div class="clear"> </div>
				</div>
				<!----End-main-header----->
			</div>
		</div>
		</body>
</html>
